import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import RegisterEventHandler
from launch.event_handlers import OnProcessExit
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.actions import IncludeLaunchDescription
import xacro

def generate_launch_description():
    use_sim_time = LaunchConfiguration('use_sim_time', default='true')

    # Robot description from xacro
    pkg_path = get_package_share_directory('my_bot')
    xacro_file = os.path.join(pkg_path, 'description', 'robot.urdf.xacro')
  
    robot_description_config = xacro.process_file(xacro_file)
    robot_description = robot_description_config.toxml()

    params = {'robot_description': robot_description, 'use_sim_time': use_sim_time}
    
    twist_mux_params = os.path.join(get_package_share_directory('my_bot'),'config','twist_mux.yaml')
    twist_mux = Node(
          package="twist_mux",
          executable="twist_mux",
          parameters=[twist_mux_params, {'use_sim_time': True}],
          remappings=[('/cmd_vel_out','/diff_cont/cmd_vel_unstamped')]


        )

    # Launch Gazebo
    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(get_package_share_directory('gazebo_ros'), 'launch', 'gazebo.launch.py')
        ),
        launch_arguments={'world': os.path.join(pkg_path, 'worlds', 'world2.world')}.items()
    )

    # Robot State Publisher
    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        output='screen',
        parameters=[params]
    )

    # Spawn robot AFTER state publisher is running
    spawn_entity = Node(
        package='gazebo_ros',
        executable='spawn_entity.py',
        arguments=['-entity', 'my_bot', '-topic', 'robot_description'],
        output='screen'
    )

    # Controller spawners (trigger AFTER spawn)
    joint_state_broadcaster_spawner = Node(
        package='controller_manager',
        executable='spawner',
        arguments=['joint_state_broadcaster', '--controller-manager', '/controller_manager'],
        output='screen'
    )

    diff_drive_spawner = Node(
        package='controller_manager',
        executable='spawner',
        arguments=['diff_cont', '--controller-manager', '/controller_manager'],
        output='screen'
    )

    # Make controller spawners wait until robot is spawned
    delay_joint_state_broadcaster_spawner = RegisterEventHandler(
        OnProcessExit(
            target_action=spawn_entity,
            on_exit=[joint_state_broadcaster_spawner],
        )
    )
    delay_diff_drive_spawner = RegisterEventHandler(
        OnProcessExit(
            target_action=joint_state_broadcaster_spawner,
            on_exit=[diff_drive_spawner],
        )
    )

    return LaunchDescription([
        gazebo,
        twist_mux,
        robot_state_publisher,
        spawn_entity,
        delay_joint_state_broadcaster_spawner,
        delay_diff_drive_spawner
    ])
