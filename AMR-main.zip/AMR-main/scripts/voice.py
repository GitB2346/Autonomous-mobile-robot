#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
import speech_recognition as sr

class VoiceTeleop(Node):
    def __init__(self):
        super().__init__('voice_teleop')
        self.publisher_ = self.create_publisher(Twist, '/cmd_vel', 10)
        self.rec = sr.Recognizer()
        self.execute_command()
        #self.mic = sr.Microphone()
        

    def listen_and_move(self):
        with sr.Microphone() as source:
            self.get_logger().info("Say a command...")
            self.rec.adjust_for_ambient_noise(source)
            audio = self.rec.listen(source)

        try:
            self.text = self.rec.recognize_google(audio)
            self.get_logger().info(f"Heard: {self.text}")
            return self.text.lower()
        except sr.UnknownValueError:
            self.get_logger().info("Didn't catch that.")
            return ""
        except sr.RequestError as e:
            self.get_logger().info(f"API Error: {e}")
            return ""

    def execute_command(self):
        while rclpy.ok():
            text = self.listen_and_move()
            twist = Twist()
            
            if "left" in text:
                    twist.linear.x = 0.0
                    twist.angular.z = +0.5
            elif "right" in text:
                    twist.linear.x = 0.0
                    twist.angular.z = -0.5
            elif "forward" in text:
                    twist.linear.x = 0.5
                    twist.angular.z = 0.0
            elif "backward" in text:
                    twist.linear.x = -0.5
                    twist.angular.z = 0.0
            elif "stop" in text:
                    twist.linear.x = 0.0
                    twist.angular.z = 0.0
            else:
                self.get_logger().info("Unknown command.")

            self.publisher_.publish(twist)
            self.get_logger().info(f"Executing command: {text}")

def main(args=None):
    rclpy.init(args=args)
    node = VoiceTeleop()

    try:
         rclpy.spin(node)
    except KeyboardInterrupt:
        pass
        
    node.destroy_node()
    rclpy.shutdown()
    
if __name__ == '__main__':
    main()