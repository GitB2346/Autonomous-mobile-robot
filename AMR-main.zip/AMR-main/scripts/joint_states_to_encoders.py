#!/usr/bin/env python3
import math
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState
from std_msgs.msg import Int32MultiArray

class JointStatesToEncoders(Node):
    def __init__(self):
        super().__init__('joint_states_to_encoders')

        # Parameters
        self.left_joint  = self.declare_parameter('left_joint',  'left_wheel_joint').value
        self.right_joint = self.declare_parameter('right_joint', 'right_wheel_joint').value
        self.ticks_per_rev = self.declare_parameter('ticks_per_rev', 360).value

        # Store last positions
        self.prev = {self.left_joint: None, self.right_joint: None}
        self.accum_ticks = {self.left_joint: 0, self.right_joint: 0}

        # Subscribers & publishers
        self.sub = self.create_subscription(JointState, '/joint_states', self.cb, 10)
        self.pub = self.create_publisher(Int32MultiArray, '/wheel/encoder_ticks', 10)

        self.get_logger().info(f"Listening for joints: {self.left_joint}, {self.right_joint}")

    def rad_to_ticks(self, rad):
        return rad * (self.ticks_per_rev / (2.0 * math.pi))

    def cb(self, msg: JointState):
        name_to_pos = dict(zip(msg.name, msg.position))

        for j in (self.left_joint, self.right_joint):
            if j in name_to_pos:
                current_rad = name_to_pos[j]
                if self.prev[j] is not None:
                    delta_rad = current_rad - self.prev[j]
                    delta_ticks = int(round(self.rad_to_ticks(delta_rad)))
                    self.accum_ticks[j] += delta_ticks
                self.prev[j] = current_rad

        # Publish accumulated ticks
        out = Int32MultiArray()
        out.data = [self.accum_ticks[self.left_joint], self.accum_ticks[self.right_joint]]
        self.pub.publish(out)

        self.get_logger().info(f"Ticks: L={out.data[0]} R={out.data[1]}")

def main():
    rclpy.init()
    node = JointStatesToEncoders()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
