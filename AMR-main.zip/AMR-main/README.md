## Autonomous Mobile Robot with ROS2, SLAM and NAV2

Autonomous Mobile Robots (AMRs) are increasingly being deployed in environments such as warehouses, hospitals, and office buildings for tasks like delivery, inspection, and surveillance. For effective deployment, an AMR must be capable of autonomous navigation, mapping, localization, and dynamic obstacle avoidance within complex and evolving indoor environments.

In this project with my fellow teammates- [Nishu Gupta](https://github.com/nishu185) , [Sumagna Das](https://github.com/sumagnadas) and [Gitika Bansal](), we built an autonomously navigating differential drive bot in an indoor environment with complex hallways and obstacles like furniture and walls. The robot uses a 2D LiDAR for scanning of the environment and a Depth camera for imagery. Additionally IMU and wheel encoders have also been added to get localization data. Additionally, the bot is also capable of working on voice-based commands for navigation. 

### Tech Stack:
- ROS2- Humble on Ubuntu 22.04 LTS
- Gazebo Classic/Ignition
- Nav2 packages 
- Localization using nav2_amcl
- SLAM (ros2 compatible slam_toolbox)
- Rviz2 for visualization and debugging
- Python and Google's Web Speech API based Speech Recogntion using 

### Build and run:
Create a workspace directory with a subdirectory named "src". This directory would contain the package mybot.
```shell
mkdir -p ~ws_name/src/mybot
cd ~/ws_name/src/mybot
```
Inside the src directory, clone this repo containing the files of mybot package. Go back to root directory and build the package.
```shell
cd ws_name/
colcon build --symlink-install
source install/setup.bash
```
Launch gazebo with the world and the bot:
```shell
ros2 launch my_bot launch_sim.launch.py
```
Run the slam_toolbox on a new terminal:
```shell
ros2 launch my_bot online_async_launch.py
```
On another new terminal run rviz2 with the preset configuration:
```shell
rviz2 -d /home/<user>/<ws_name>/src/my_bot/config/map.rviz
```
For localization:
```shell
ros2 launch nav2_bringup localization_launch.py map:=/home/<user>/<ws_name>/src/my_bot/map/my_map_save.yaml use_sim_time:=true
```

Start up Nav2 navigation stack and load the saved map on a new terminal:
```shell
ros2 launch my_bot navigation_launch.py
```
For running the voice-based navigation:
```shell
ros2 run my_bot voice.py
```
Use the voice-commands “Forward”, “Backward”, “Left”, “Right”, “Stop” to navigate through the world. You might have to repeat the command twice because of background noise and other disturbances. Note that it requires an internet connection for the speech recognition to work but detection is quite accurate.




